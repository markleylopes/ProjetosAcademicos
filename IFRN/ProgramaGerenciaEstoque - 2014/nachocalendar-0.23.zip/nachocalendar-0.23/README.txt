README
======

Updates:
========

Check out the web site at:

http://nachocalendar.sf.net

How to use it:
==============

Read the javadocs in the doc/ dir

Quick Start:
============

run the demo in the lib folder (you must have a Java Runtime Environment ver 1.4.0 or superior):

cd lib

java -jar nachocalendar-demo.jar


More docs to come...